// REngineLUAU / R'EL Studio - Electron desktop shell (source, not compiled EXE)
const {app, BrowserWindow, shell} = require('electron');
const path = require('path');
function createWindow() {
 const win = new BrowserWindow({
  title:"R'EL Studio - REngineLUAU",
  width:1440,height:900,minWidth:950,minHeight:650,
  backgroundColor:'#0a101d',autoHideMenuBar:true,
  webPreferences: { nodeIntegration:false,contextIsolation:true,sandbox:true }
 });
 // Local standalone app. Firebase Auth may require HTTPS version + domain authorization.
 win.loadFile(path.join(__dirname,'index.html'));
 win.webContents.setWindowOpenHandler(({url})=>{
   if (/^https:\/\//.test(url))shell.openExternal(url);
   return {action:'deny'};
 });
}
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
