R'EL Studio Windows Wrapper (Electron SOURCE, NOT an installer/exe).
Requires Node.js installed. In this folder:
  npm install
  npm start
  npm run package-windows
The Windows executable build requires supported packaging tools and may need a Windows machine.
Local file:// mode is for offline world editing. For cloud login use the HTTPS Render PWA and
configure Firebase Authentication authorized domains.
Never store admin credentials in this project.
